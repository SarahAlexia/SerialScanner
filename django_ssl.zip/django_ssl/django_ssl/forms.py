from django import forms

class SearchForm(forms.Form):
    serial = forms.CharField(label="Enter Serial", required=True)
